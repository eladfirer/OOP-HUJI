package pepse.world.trees;

import pepse.util.Constants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.function.Function;

/**
 * this class is responsible for creating the flora in game
 */
public class Flora {

    private final Function<Float, Float> callbackGetHeight;
    private Random random = new Random();
    private static Map<Integer,Tree> treeRecord = new HashMap<>();

    /**
     * flora constructor
     * @param callbackGetHeight callback to get height (y) of ground in a specific x location
     */
    public Flora (Function<Float,Float> callbackGetHeight){
        this.callbackGetHeight = callbackGetHeight;
    }

    /**
     * creates in range of minX and maxX trees to put in game
     * @param minX x to start creating trees
     * @param maxX x to stop creating trees
     * @return array list of trees to put in game
     * @see Tree
     */
    public ArrayList<Tree> createInRange(int minX, int maxX) {

        minX = (int) Math.floor((double) minX / Constants.BLOCK_SIZE) * Constants
                .BLOCK_SIZE;
        maxX = (int) Math.ceil((double) maxX / Constants.BLOCK_SIZE) * Constants
                .BLOCK_SIZE;

        ArrayList<Tree> trees = new ArrayList<>();
        for (int x = minX; x < maxX; x += Constants.BLOCK_SIZE){
            float groundHeight = callbackGetHeight.apply((float)x);
            // checking for trees in tree record in order to maintain the world look.
            if(treeRecord.containsKey(x)){
                if(treeRecord.get(x) != null){
                    trees.add(treeRecord.get(x));
                }
                continue;
            }

            // preventing trees being next to each other
            if(x!=minX && treeRecord.get(x- Constants.BLOCK_SIZE)!=null){
                treeRecord.put(x,null);
                continue;
            }
            if(x==maxX - Constants.BLOCK_SIZE){
                // we cant guarantee that this key exists
                if(treeRecord.containsKey(maxX)){
                    if(treeRecord.get(maxX) != null){
                        treeRecord.put(x,null);
                        continue;
                    }
                }
            }

            // randomness for creating tree
            if(random.nextDouble()  < 0.1){
                Tree newTree = Tree.createTree(x, groundHeight);
                trees.add(newTree);
                treeRecord.put(x,newTree);
            }
            else{
                treeRecord.put(x,null);
            }
        }
        return trees;
    }
}
